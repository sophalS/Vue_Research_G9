<template>
  <div>
    <input type="text" placeholder="Name">
  </div>
  <div>

  <button>submit</button>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>